package com.fileimport.daoImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.fileimport.dao.FileUploadDao;
@Transactional
@Repository
public class FileUploaddaoImpl implements FileUploadDao {

	@Autowired
	MongoTemplate mongoTemplate;
	
	@Override
	public void save(Object item, String dbName) {
		mongoTemplate.save(item, dbName);
	}

}
