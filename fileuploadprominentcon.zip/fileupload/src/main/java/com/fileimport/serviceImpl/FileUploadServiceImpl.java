package com.fileimport.serviceImpl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.servlet.ServletContext;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.fileimport.dao.FileUploadDao;
import com.fileimport.services.FileUploadService;

@Service
public class FileUploadServiceImpl implements FileUploadService {

	// ServletContext is information shared all servlet and it created by web
	// container at time of deploying the project
	@Autowired
	ServletContext context;

	@Autowired
	FileUploadDao dao;
	// business logics for File Upload

	@Override
	public Map<String, String> uploadFile(MultipartFile file) {
		Map<String, String> res = new HashMap<>();
		Runnable updateRun = new Runnable() {
			@Override
			public void run() {
				try {
					String path = context.getRealPath("/");
					File fileImport = new File(path, "Import");
					if (!fileImport.exists()) {
						fileImport.mkdir();
					}
					String fileToParse = fileImport.getAbsolutePath();
					fileToParse = fileToParse + "/";
					File transferfile = new File(fileToParse, "sample_json.json");
					file.transferTo(transferfile);
					JSONParser jsonParser = new JSONParser();
					FileReader reader = new FileReader(transferfile);
					BufferedReader buffer = new BufferedReader(reader);

					StringBuilder Builder = new StringBuilder();
					String line = null;
					while ((line = buffer.readLine()) != null) {
						Builder.append(line);
					}
					reader.close();

					JSONObject list = (JSONObject) jsonParser.parse(Builder.toString());
					// education
					JSONArray jsonArrayofExducation = (JSONArray) list.get("education");
					for (Object item : jsonArrayofExducation) {
						dao.save(item, "education");
					}
					list.remove("education");
					// emails
					JSONArray jsonArrayofEmails = (JSONArray) list.get("emails");
					for (Object item : jsonArrayofEmails) {
						dao.save(item, "emails");
					}
					list.remove("emails");
					// experience
					JSONArray jsoArrayofEducation = (JSONArray) list.get("experience");
					for (Object item : jsoArrayofEducation) {
						dao.save(item, "experience");
					}
					list.remove("experience");
					// profiles
					JSONArray jsonArrayofProfiles = (JSONArray) list.get("profiles");
					for (Object item : jsonArrayofProfiles) {
						dao.save(item, "profiles");
					}
					list.remove("profiles");
					// main
					dao.save(list, "main1");
					transferfile.delete();
					transferfile.deleteOnExit();
					
				} catch (IOException | ParseException ex) {
					ex.printStackTrace();
				}
			}
		};
		ExecutorService exService = Executors.newFixedThreadPool(15);
		exService.execute(updateRun);
		if (exService.isTerminated()) {
			exService.shutdown();
		}
		res.put("Success", "Interted Successfully");
		return res;
	}

}
