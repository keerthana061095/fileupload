package com.fileimport.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fileimport.services.FileUploadService;

@RestController
public class FileUploadController {
	
	@Autowired
	FileUploadService service;
	
	@GetMapping("/getdata")
	public String getdata() {
		String name = "hi";
		return name;
	}
	
	
	@RequestMapping(value = "/import")
	public Map<String,String> fileImport(@RequestParam("file") MultipartFile file) {
		Map<String,String> res = service.uploadFile(file);
		return res;
		
	}

			
}
