package com.fileimport.services;

import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

public interface FileUploadService {

	Map<String, String> uploadFile(MultipartFile file);

}
