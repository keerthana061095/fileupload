package com.fileimport.dao;

public interface FileUploadDao {

	void save(Object item, String string);

}
